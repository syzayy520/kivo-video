#!/bin/zsh
# Rex 1.0.2 REA 拆解成果 -> /Volumes/系统/kivo video/docs/reference 一键落地
#
# 用法：
#   1) 在「访达」里双击本文件；或
#   2) 终端执行： zsh "/Users/huyasi/tools/rex-analysis/安装到docs-reference.command"
#
# 前置条件：目标 NTFS 卷必须以「可写」方式挂载。
#   macOS 内置 FSKit NTFS 驱动只有只读模式，需要第三方 NTFS 写驱动
#   （Paragon / Tuxera / macFUSE + ntfs-3g）启用后重新挂载。
#
# 可选环境变量：
#   REX_LAYOUT=root          直接放 docs/reference/ 根目录
#   REX_LAYOUT=rex-teardown  放到已有的 rex-teardown/ 子目录（默认）
#   REX_FORCE=1              覆盖同名文件（默认不覆盖）

set -eu

SRC="/Users/huyasi/tools/rex-analysis"
DST="/Volumes/系统/kivo video/docs/reference"
LAYOUT="${REX_LAYOUT:-rex-teardown}"
FORCE="${REX_FORCE:-0}"

DOCS=(
  "Rex_UI结构复刻说明书.md"
  "Rex_动效与交互全量拆解.md"
  "Rex_动效参数表.csv"
)

echo "== Rex 拆解成果落地 =="
echo "源: $SRC"
echo "目标: $DST"

if [[ ! -d "$DST" ]]; then
  echo "X 目标目录不存在: $DST"
  exit 1
fi
if [[ ! -w "$DST" ]]; then
  echo "X 目标仍为只读挂载: $DST"
  echo "  macOS 内置 NTFS(FSKit) 只提供只读模式。请先启用 NTFS 写入支持并重新挂载后重试。"
  echo "  也可靠切换到 Windows 侧写入同一分区。"
  exit 1
fi

case "$LAYOUT" in
  root)         OUT="$DST" ;;
  rex-teardown) OUT="$DST/rex-teardown" ;;
  *) echo "X 未知 REX_LAYOUT=$LAYOUT (只允许 root / rex-teardown)"; exit 1 ;;
esac

mkdir -p "$OUT/evidence/strings" "$OUT/evidence/assets"

for f in "${DOCS[@]}"; do
  if [[ ! -f "$SRC/$f" ]]; then
    echo "X 缺少源文件: $SRC/$f"
    exit 1
  fi
  if [[ -f "$OUT/$f" && "$FORCE" != "1" ]]; then
    echo "= 已存在，跳过: $f  (REX_FORCE=1 可覆盖)"
  else
    cp "$SRC/$f" "$OUT/$f"
    echo "+ $f"
  fi
done

cp -R "$SRC/strings/." "$OUT/evidence/strings/"
cp -R "$SRC/assets/."  "$OUT/evidence/assets/"

echo
echo "== 校验 =="
ok=1
for f in "${DOCS[@]}"; do
  if cmp -s "$SRC/$f" "$OUT/$f"; then
    echo "OK  $f  $(wc -c < "$OUT/$f") bytes"
  else
    echo "BAD $f"; ok=0
  fi
done
printf 'OK  证据包: strings %s 份 / assets %s 份\n' \
  "$(find "$OUT/evidence/strings" -type f | wc -l | tr -d ' ')" \
  "$(find "$OUT/evidence/assets" -type f | wc -l | tr -d ' ')"

if [[ "$ok" = "1" ]]; then
  echo
  echo "完成 ✅  $OUT"
  ls -lh "$OUT"
else
  echo "校验未通过，请检查。"
  exit 1
fi
